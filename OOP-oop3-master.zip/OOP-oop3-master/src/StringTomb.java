import java.util.Scanner;


public class StringTomb {

	public static void main(String[] args) {
		double a, b;
		int oper;
		Scanner input = new Scanner(System.in);
		System.out.println("Add meg az a értékét: ");
		a = input.nextDouble();
		System.out.println("Add meg a b értékét: ");
		b = input.nextDouble();
		System.out.println("1=add, 2=sub, 3=mult, 4=div");
		System.out.println("Add meg a műveletet: ");
		oper = input.nextInt();
		double result=0;
		switch (oper){
		case 1:
			result = a+ b;
            break;
		case 2:
			result = a - b;
			break;
		case 3:
			result = a * b;
			break;
		case 4:
			if (b!=0)
			{
			result = a / b;
			break;
			}
			else System.out.println("Nem lehet 0-val osztani");
		default:
			System.out.println("Ne szívass");
		}
		input.close();
		System.out.println("Eredmény: "+result);
	}

}
