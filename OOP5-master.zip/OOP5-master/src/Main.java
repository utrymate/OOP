import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Teglalap a= new Teglalap(6, 4); //ekkor a oldal 6, b oldal 4 - ezert van 2 konstruktor
		Teglalap b= new Teglalap(3);
		Teglalap c=a; //konstruktor helyett felveszi a-nak ertekeit
		
		System.out.println(a + "\n" + b + "\n" + c);
		
		a.setSides(5, 6);
		
		System.out.println(a + "\n" + b + "\n" + c);
		
		a.setBothSide(3);
		System.out.println(a==b);
		System.out.println(a==c);
		System.out.println(a.hasSameSide(a));
		
		Random random = new Random();

		Teglalap[] teglalapArray= new Teglalap[10];
		for (int i = 0; i < 10; i++) {
			teglalapArray[i] = new Teglalap(random.nextInt(8)+2, random.nextInt(8)+2);
			System.out.println(teglalapArray[i]);
		}
		
		int min = 0;
		for (int i = 0; i < 10; i++) {
			if (teglalapArray[min].getArea() > teglalapArray[i].getArea())
				min = i;
			}
		System.out.println("\n" + teglalapArray[min]);
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a b side");
		int aside = scanner.nextInt();
		int bside = scanner.nextInt();
		Teglalap userTeglalap = new Teglalap(aside, bside);
		int counter = 0;
		for (int i = 0; i < teglalapArray.length; i++) {
			if(userTeglalap.hasBiggerArea(teglalap)) {
				counter++;
			}
		}
		System.out.println("There were "+ counter + " smaller rectangles");
		
		int mindex = -1;
		boolean matching = false;
		for (int i = 0; i < teglalapArray.length; i++) {
			if (userTeglalap.hasSameSide(teglalapArray[i]) && mindex == -1)
				mindex = i;
				matching = true;
		}
		if (mindex!=-1) {
			System.out.println(mindex);
		}
		else System.out.println("No matching");
		System.out.println(mindex);
		
		
	}

}
