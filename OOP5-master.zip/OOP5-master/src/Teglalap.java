
public class Teglalap {

	private int aSide;
	private int bSide;

	
	public Teglalap(int aSide, int bSide) { //sajat adattagjait beallitja a parameterkent kapott adatokra
		this.aSide= aSide;
		this.bSide= bSide;
	}
	
	public Teglalap(int sides) { //parameter szignatura itt: int sides
		this.aSide= sides;
		this.bSide= sides;
	}
	
	public int getArea() {
		return aSide*bSide;
	}

	public String toString() {
		return aSide + ", " + bSide + ": " + getArea();
	}

	public int getaSide() {
		return aSide;
	}

	public int getbSide() {
		return bSide;
	}

	public void setSides(int aSide, int bSide) {
		this.aSide = aSide;
		this.bSide = bSide;
	}
	
	public void setBothSide(int sides) {
		this.aSide = sides;
		this.bSide = sides;
	}

	public boolean hasBiggerArea(Teglalap teglalap) {
		if (this.getArea()>teglalap.getArea()) {
			return true;
		}
		else return false;
	}
	
	public boolean hasSameSide(Teglalap teglalap) {
		if (this.getaSide() == teglalap.getaSide() && this.getbSide() == teglalap.getbSide())
			return true;
		else return false;
	}
	
	
	
	
}
