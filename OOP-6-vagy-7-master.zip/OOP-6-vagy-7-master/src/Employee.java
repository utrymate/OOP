import java.time.LocalDate;


public class Employee {

	//6. gyakorlat 1. feladat
	
	private String employeeName;
	private long salary;
	private LocalDate birthday;
	
	static int pensionRemainingAge=65; //1. resz
	
	
	
	public Employee(String employeeName, long salary, LocalDate birthday) { //int age volt eddig
		super();
		this.employeeName = employeeName;
		this.salary = salary;
		this.birthday = birthday;
	}
	
	public Employee(String employeeName, int age) { //2. resz
		super();
		this.employeeName = employeeName;

		this.birthday = birthday;
		this.salary = (LocalDate.now().getYear() - birthday.getYear())*10000;
	}
	
	public int getRemainingYearsUntilPension() { //3. resz
		return LocalDate.now().getYear() - birthday.getYear(); //visszaadja a ny.k.h.-t, kivonja a korat
	}
	
	
	public static int getPensionRemainingAge() {
		return pensionRemainingAge;
	}

	public static void setPensionRemainingAge(int pensionRemainingAge) {
		Employee.pensionRemainingAge = pensionRemainingAge;
	}

	public static Employee getYoungerEmployee(Employee employee1, Employee employee2) {
		if (employee1.getRemainingYearsUntilPension() > employee2.getRemainingYearsUntilPension())
			return employee1;
		else return employee2;
	}
	
	
	//4. resz source-generateToString-gel csinalva
	


	public long increaseSalary(long increase, long employeeSalary) {
		return employeeSalary+=increase;
	}
	
	
	@Override
	public String toString() {
		return "Employee [employeeName=" + employeeName + ", salary=" + salary
				+ ", birthday=" + birthday
				+ ", getRemainingYearsUntilPension()="
				+ getRemainingYearsUntilPension() + "]";
	}

	public String displayInfo() {
		return "Salary: "+this.salary+ " Name: "+ this.employeeName;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}
	
	public boolean isInSalaryRange(long salaryStart, long salaryEnd) {
		if(this.salary < salaryEnd && this.salary >= salaryStart) {
			return true;
		}
		else return false;
	}
	
	public long getTax() {
		return (long) (this.salary*0.16);
	}
	
	public boolean hasHigherSalary(Employee asd) {
		if (this.salary > asd.salary) {
			return true;
		}
		else return false;
	}
}