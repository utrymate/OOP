import java.util.Scanner;
import java.util.concurrent.locks.Condition;


public class Main {

	public static void main(String[] args) {
		
		//futt.oszt. 0. resz:
		Scanner scanner = new Scanner(System.in);
		System.out.println("Pls input hanyan vannak: ");
		int numberOfEmployees = scanner.nextInt();
		
		Employee[] employees = new Employee[numberOfEmployees];
		
		for (int i = 0; i < employees.length; i++) {
			System.out.println("Name of the employee: ");
			String tempName = scanner.next();
			System.out.println("Age: ");
			int tempAge = scanner.nextInt();
			employees[i] = new Employee(tempName, tempAge);
			System.out.println(employees[i]); //itt irjuk ki az adatait - 1. resz 1. fele
		}
		
		Employee.setPensionRemainingAge(75); //mivel 1 peldanyhoz sincs kotve, hanem staticus adattagot valtoztat meg, ezert az osztaly nevevel hivatkozunk ra
		
		for (int i = 0; i < employees.length; i++) { //1. resz
			System.out.println(employees[i]);
		}
		
		
		for (Employee employee : employees) { //2. resz
			if (employee.getRemainingYearsUntilPension() < 5) {
				System.out.println(employee);
			}
			
		}
		
		int avgAgeRemaining=0;
		
		for (Employee employee : employees) {
			avgAgeRemaining+=employee.getRemainingYearsUntilPension();
		}
		avgAgeRemaining/=employees.length; //atlagszamito
		
		for (Employee employee : employees) {
			if (employee.getRemainingYearsUntilPension() > avgAgeRemaining) {
				System.out.println(employee); //kiirom akinek tobb van - 3.resz
			}
		}
		//rendezes - utolso pont:
		for (int i = 0; i < employees.length; i++) {
			int max=i;
			for (int j = i+1; j < employees.length; j++) {
				if(employees[j].getRemainingYearsUntilPension() > employees[max].getRemainingYearsUntilPension()) {
					max=j;
				}
			}
		Employee tEmployee = new Employee(employees[i].getEmployeeName(), employees[i].getAge()); //segedvaltozo
		employees[i]=new Employee(employees[max].getEmployeeName(), employees[max].getAge()); //i.-be berak a max
		employees[max] = new Employee(tEmployee.getEmployeeName(), tEmployee.getAge()); //max-ba be kell rakni az i.-edikbe (vissza kell cserelni a 2-t)
		
		}
		
		for (Employee employee : employees) {
			System.out.println(employee);
		}
		
		
		for (int i = 0; i < employees.length; i++) {
			int min=i;
			for (int j = i+1; j < employees.length; j++) {
				if(employees[j].getRemainingYearsUntilPension() < employees[min].getRemainingYearsUntilPension()) {
					min=j;
				}
			}
		Employee tEmployee = new Employee(employees[i].getEmployeeName(), employees[i].getAge()); //segedvaltozo
		employees[i]=new Employee(employees[min].getEmployeeName(), employees[min].getAge()); //i.-be berak a max
		employees[min] = new Employee(tEmployee.getEmployeeName(), tEmployee.getAge()); //max-ba be kell rakni az i.-edikbe (vissza kell cserelni a 2-t)
		
		}
		
		for (Employee employee : employees) {
			System.out.println(employee);
		}
	}

}
