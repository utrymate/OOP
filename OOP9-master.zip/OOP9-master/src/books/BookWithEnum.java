package books;



public class BookWithEnum extends Book {
	

}
