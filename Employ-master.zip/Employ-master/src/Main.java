
public class Main {

	public static void main(String[] args) {
//		Employee asd = new Employee();
////		asd.employeeName = "Janoska";
////		asd.salary = 51341; //ezt nem hasznalhatjuk, mert privat adattag van
//		
//		asd.setEmployeeName("Jancsi");
//		asd.setSalary(9876);
//		
////		asd.salary=asd.increaseSalary(500, asd.salary);
////		System.out.println(asd.displayInfo(asd.salary, asd.employeeName));
//		
//		Employee asd2 = new Employee();
//		asd2.setEmployeeName("Geza");
//		asd2.setSalary(3400);
//		
//		System.out.println(asd.displayInfo() +"\n"+ asd2.displayInfo());
//		
//		System.out.println(asd2.isInSalaryRange(500, 10000)+"\n"+asd.isInSalaryRange(500, 2000)+"\n"+asd.getTax()+"\n"+asd.hasHigherSalary(asd2));
		
		Employee[] empArray= new Employee[10];
		
		for (int i = 0; i < empArray.length; i++) {
			empArray[i]= new Employee();
			empArray[i].setSalary(i*1000+i*200);
			empArray[i].setEmployeeName("Petike"+i);
		}
		
		int maxi= 0;
		
		for (int i = 1; i < empArray.length; i++) {
			if(empArray[i].hasHigherSalary(empArray[maxi])) {
				maxi=i;
			}
		}
		
		System.out.println(maxi);
		
		int szam=0;
		for (int i = 0; i < empArray.length; i++) {
			if(empArray[i].isInSalaryRange(2000, 5000))
			{
				szam++;
			}
		}
		
		System.out.println(szam);
		
		long atlag=0;
		for (Employee emp : empArray) {
			atlag+=emp.getSalary();
		}
		atlag/=empArray.length;
		System.out.println(atlag);
		
		int osszeg=0;
		for (int i = 0; i < empArray.length; i++) {
			osszeg+=empArray[i].getTax();
		}
		System.out.println(osszeg);
	}
}

