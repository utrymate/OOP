//gyak 6 masodik feladat

package sajat.elso;

public class Number {
	double tures = 0.001;
	private double realNum;

	public Number(double realNum) {
		super();
		this.realNum = realNum;
	}

	public double getRealNum() {
		return realNum;
	}

	public void setRealNum(double realNum) {
		this.realNum = realNum;
	}

	public boolean TuresenBelul(double number) {
		if(Math.abs(realNum-number)<tures)
		{
			return true;
		}
		else return false;
	}


}

