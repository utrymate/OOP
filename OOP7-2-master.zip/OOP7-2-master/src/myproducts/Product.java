package myproducts;

public class Product {
	private String name;
	private int netPrise;
	private int afakulcs;
	
	public Product(String name, int netPrise, int afakulcs) {
		super();
		this.name = name;
		this.netPrise = netPrise;
		this.afakulcs = afakulcs;
	}
	
	public int brutto_ar() {
		return this.netPrise + this.netPrise * this.afakulcs/100;
	}

	@Override
	public String toString() {
		return "Product [Name=" + name + ", brutto_ar()=" + brutto_ar() + "]";
	}
	
	public void incAr(int szazalek) {
		int novel = this.netPrise*(szazalek/100);
		this.netPrise = novel + this.netPrise;
	}
}
