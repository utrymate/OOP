package myproducts;

import java.io.ObjectInputStream.GetField;

public class Bread extends Product{ //extends-szel szarmaztatok
	
	private float volume;

	public Bread(String name, int netPrise, int afakulcs, float volume) {
		super(name, netPrise, afakulcs);
		this.volume=volume;
	}

	public float getVolume() {
		return volume;
	}

	@Override
	public String toString() {
		return "Bread [volume=" + volume + ", toString()=" + super.toString() //volume + ososztaly toStringje
				+ "]";
	}
	
	public int egysegAr() {
		return (int) (brutto_ar()/volume);
	}
	
	public static boolean isBiggerInVolume (Bread a, Bread b) { //static = oszt.szintu metodus
		if (a.egysegAr() > b.egysegAr())
			return true;
		else return false;
	}
}
