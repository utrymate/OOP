package myproducts;

public class Main {
	
	public static void main(String[] args) {
		Product product = new Product("Petike", 200, 27);
		Bread bread = new Bread("Arpa", 250, 14, 5);
		System.out.println(product + " " + bread);
		
		Product product2 = new Bread("Rozs", 300, 20, 10);
		System.out.println(product2);
		
		Bread bread2 = new Bread("Legjobb", 600, 14, 1);
		if (Bread.isBiggerInVolume((Bread) product2, bread2))
			System.out.println(product2);
		else System.out.println(bread2);

	}

}
