package tartalyos.fut;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import tartalyos.Tartaly;

public class Proba {
	public static void main(String[] args) {
		Tartaly[] tartArr = new Tartaly[5];
		
		for (int i = 0; i < tartArr.length; i++) {
			tartArr[i] = new Tartaly(i, i*2);
		}
		
		tartArr[2] = new Tartaly(30, 100);
		
		for (Tartaly tartaly : tartArr) {
			System.out.println(tartaly);
		}
		int marx=0;
		for (int i = 1; i < tartArr.length; i++) {
			if(tartArr[i].isBiggerThan(tartArr[marx])) {
				marx = i;
			}
		}
		
		System.out.println(tartArr[marx]+" "+marx);
		Tartaly maxTartaly= tartArr[0];
		
		for (int i = 1; i < tartArr.length; i++) {
			if (maxTartaly.getTerfogat()<tartArr[i].getTerfogat()) {
				maxTartaly=tartArr[i];
			}
		}
		
	}

}
