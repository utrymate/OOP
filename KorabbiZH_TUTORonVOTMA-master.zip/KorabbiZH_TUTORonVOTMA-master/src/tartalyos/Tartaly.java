package tartalyos;

public class Tartaly extends Tarolo {
	
	private double nyomas;

	public Tartaly(int terfogat, double nyomas) {
		super(terfogat);
		this.nyomas=nyomas;
	}

	
	public double getNyomas() {
		return nyomas;
	}


	public void setNyomas(double nyomas) {
		this.nyomas = nyomas;
	}


	@Override
	public boolean isDangerous() {
		
		if ((getTerfogat()*nyomas)>100) {
			return true;
		}
		else return false;
	}

	@Override
	public String toString() {
		return "Tartaly [nyomas=" + nyomas + "terfogat= " +getTerfogat()+", veszelyes="+isDangerous() + "]";
	}

	public boolean isBiggerThan(Tartaly tartaly) {
		if (this.nyomas>tartaly.getNyomas()) {
			return true;
		}
		else return false;
	}
	//oszt. szintu methodus = static
	
	public static Tartaly getBiggerTartaly(Tartaly tart1, Tartaly tart2) {
		if (tart1.getTerfogat()>tart2.getTerfogat()) {
			return tart1;
		}
		else return tart2;
	}
}
