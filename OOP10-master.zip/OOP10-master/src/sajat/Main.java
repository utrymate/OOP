package sajat;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int[] t1 = new int[5];
		beolvasas(t1, 5);
		for (int i : t1) {
			System.out.println(i);
		}
		
	}
	
	public static void beolvasas(int [] tomb, int m) {
		for (int i = 0; i < 5; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Add meg az "+(i+1)+". elemet: ");
			if(sc.nextInt()<0)
			{
				System.out.println("Ejnye!");
			}
			else
			{
				tomb[i] = sc.nextInt();
			}
		}
	}
}
