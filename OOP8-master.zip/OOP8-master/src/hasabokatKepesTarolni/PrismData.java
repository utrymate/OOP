//8. gyak 1. feladat 2. fele

package hasabokatKepesTarolni;

import geometric.Cylinder;
import geometric.Prism;

public class PrismData { //osztaly, ami peldanyokat tarol
	Prism [] prismArray;

	public PrismData(int elemNumb) {
		super();
		prismArray = new Prism[elemNumb];
	}
	
	public int getNumbOfPrisms() {
		return prismArray.length;
	}
	
	public void setPrism(int indeksz, Prism prism) { //1.
		prismArray[indeksz]=prism;
	}

	public Prism[] getPrismArray() { //2.
		return prismArray;
	}

	public Prism getPrismIndeksz(int index) { //3.
		return prismArray[index];
	}
	
	public int getNumbOfNulls() {//4.
		int counter = 0;
		
		for (Prism prism : prismArray) {
			if (prism!=null) {
				counter++;
			}
		}
		return counter;
	}
	
	public double getAtlag() { //5.
		double atlag = 0;
		for (Prism prism: prismArray) {
			if (prism!=null) {
				atlag += prism.getVolume();
			}
		}
		return atlag/getNumbOfNulls();
	}
	
	public int getNumbOfCili() {
		int ct=0;
		for (Prism prism : prismArray) {
			if (prism instanceof Cylinder) {
				ct++;
			}
		}
		return ct;
	}
}
