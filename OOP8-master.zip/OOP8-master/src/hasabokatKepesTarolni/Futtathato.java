package hasabokatKepesTarolni;

import geometric.Cuboid;
import geometric.Cylinder;
import geometric.Prism;

public class Futtathato {

	public static void main(String[] args) {
		PrismData data = new PrismData(5);
		Prism cubi = new Cuboid(5,10,5);
		//ugyanaz a funkciojuk ezeknek:
		Prism cili = new geometric.Cylinder(21, 5);
		Cylinder masikcili = new Cylinder(4, 5);
		
		data.setPrism(0, cubi); //null erteku tombelem
		data.setPrism(2, cili);
		data.setPrism(4, masikcili);
		
		for (int i = 0; i < data.getNumbOfPrisms(); i++) {
			System.out.println(data.getPrismIndeksz(i));
		}
		
		System.out.println(data.getAtlag());
		System.out.println(data.getNumbOfCili());
	}

}
