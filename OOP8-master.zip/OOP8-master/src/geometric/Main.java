package geometric;

public class Main {
	public static void main(String[] args) {
		Cylinder cylinder1 = new Cylinder(12, 9);
		System.out.println(cylinder1);
		
		Cuboid cubi = new Cuboid(122,21,3);
		System.out.println(cubi + "\n");
		
		if (cylinder1.hasBiggerVolumeThan(cubi)) {
			System.out.println("Cyli nagyobb");
		}
		else System.out.println("A másik");
	}
}
