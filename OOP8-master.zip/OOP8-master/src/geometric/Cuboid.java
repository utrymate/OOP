package geometric;

public class Cuboid extends Prism {

	public Cuboid(int height, double a, double b) {
		super(height);
		this.a = a;
		this.b = b;
	}

	private double a;
	private double b;
	
	@Override
	public double getBaseArea() {
		return a*b;
	}

	@Override
	public String toString() {
		return "Cuboid [a=" + a + ", b=" + b + ", getHeight()=" + getHeight()
				+ "]";
	}
	
}
